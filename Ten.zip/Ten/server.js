const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;


mongoose.connect("mongodb://localhost:27017/todoDB", {});

const todoSchema = new mongoose.Schema({
    task: String
});
const Todo = mongoose.model("Todo", todoSchema);


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));


app.get("/", async (req, res) => {
    const todos = await Todo.find();
    res.sendFile(path.join(__dirname, "views", "index.html"));
});

app.get("/todos", async (req, res) => {
    const todos = await Todo.find();
    res.json(todos);
});

app.get("/count", async (req, res) => {
    const count = await Todo.countDocuments();
    res.json({ count });
});

app.post("/add", async (req, res) => {
    const newTodo = new Todo({ task: req.body.task });
    await newTodo.save();
    res.redirect("/");
});

app.post("/delete", async (req, res) => {
    await Todo.findByIdAndDelete(req.body.id);
    res.redirect("/");
});


app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});