const express = require("express");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static("public"));

// In-memory course storage (instead of a database)
let courses = [
    { id: 1, title: "JavaScript Basics", description: "Learn JavaScript from scratch" },
    { id: 2, title: "Node.js Express", description: "Build web apps with Node.js" }
];

// Get all courses
app.get("/courses", (req, res) => {
    res.json(courses);
});

// Add a new course
app.post("/courses", (req, res) => {
    const newCourse = { id: courses.length + 1, ...req.body };
    courses.push(newCourse);
    res.json({ message: "Course added successfully", course: newCourse });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
