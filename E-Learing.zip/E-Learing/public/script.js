function loadCourses() {
    fetch('/courses')
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("courseList");
            list.innerHTML = "";
            data.forEach(course => {
                let li = document.createElement("li");
                li.textContent = `${course.title} - ${course.description}`;
                list.appendChild(li);
            });
        });
}

function addCourse() {
    const title = document.getElementById("title").value;
    const description = document.getElementById("description").value;

    fetch('/courses', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description })
    })
    .then(response => response.json())
    .then(() => {
        loadCourses();
        document.getElementById("title").value = "";
        document.getElementById("description").value = "";
    });
}
