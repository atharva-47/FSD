const express = require("express");
const path = require("path");
const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true })); // Parse form data
app.use(express.json());

let tasks = [];

app.set("view engine", "ejs"); // Set EJS for templates

app.get("/", (req, res) => res.render("index", { tasks }));

app.post("/tasks", (req, res) => {
    tasks.push(req.body.task);
    res.redirect("/");
});

app.post("/tasks/:index", (req, res) => {
    tasks.splice(req.params.index, 1); // Remove task by index
    res.redirect("/");
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
