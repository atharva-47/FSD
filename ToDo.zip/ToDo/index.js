const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));

let tasks = []; // Array to store tasks

// Home Route (Shows the form)
app.get('/', (req, res) => {
    res.render('form');  // Only displays the form
});

// Add Task Route (Redirects to /table)
app.post('/add', (req, res) => {
    const newTask = req.body.task;
    if (newTask) {
        tasks.push(newTask);
    }
    res.redirect('/table');  // Redirect to table after adding a task
});

// Table Route (Displays the task list)
app.get('/table', (req, res) => {
    res.render('table', { tasks });
});

// Delete Task Route
app.post('/delete', (req, res) => {
    const index = req.body.index;
    if (index !== undefined) {
        tasks.splice(index, 1);
    }
    res.redirect('/table');
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
