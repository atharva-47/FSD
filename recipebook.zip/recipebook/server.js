// Import dependencies
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

// Initialize Express app
const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(cors());

// Sample data store
const recipesFile = path.join(__dirname, 'data', 'recipes.json');
if (!fs.existsSync(path.dirname(recipesFile))) {
    fs.mkdirSync(path.dirname(recipesFile), { recursive: true });
}
if (!fs.existsSync(recipesFile)) {
    fs.writeFileSync(recipesFile, JSON.stringify([]));
}

// Helper function to read and write recipes
const getRecipes = () => JSON.parse(fs.readFileSync(recipesFile));
const saveRecipes = (recipes) => fs.writeFileSync(recipesFile, JSON.stringify(recipes, null, 2));

// Routes
app.get('/recipes', (req, res) => {
    res.json(getRecipes());
});

app.post('/recipes', (req, res) => {
    const recipes = getRecipes();
    const newRecipe = req.body;
    newRecipe.id = recipes.length + 1;
    recipes.push(newRecipe);
    saveRecipes(recipes);
    res.status(201).json(newRecipe);
});

app.get('/recipes/:id', (req, res) => {
    const recipe = getRecipes().find(r => r.id === parseInt(req.params.id));
    if (recipe) {
        res.json(recipe);
    } else {
        res.status(404).json({ message: 'Recipe not found' });
    }
});

app.put('/recipes/:id', (req, res) => {
    const recipes = getRecipes();
    const index = recipes.findIndex(r => r.id === parseInt(req.params.id));
    if (index !== -1) {
        recipes[index] = { ...recipes[index], ...req.body };
        saveRecipes(recipes);
        res.json(recipes[index]);
    } else {
        res.status(404).json({ message: 'Recipe not found' });
    }
});

app.delete('/recipes/:id', (req, res) => {
    let recipes = getRecipes();
    const filteredRecipes = recipes.filter(r => r.id !== parseInt(req.params.id));
    if (recipes.length !== filteredRecipes.length) {
        saveRecipes(filteredRecipes);
        res.json({ message: 'Recipe deleted' });
    } else {
        res.status(404).json({ message: 'Recipe not found' });
    }
});

// Serve frontend
app.use(express.static('public'));

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
